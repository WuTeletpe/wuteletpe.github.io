#!/usr/bin/env python
#-*- coding:utf-8 -*-

def test():
    print "hello world!"

if __name__ == '__main__':
    test()